<div align="center">

<img src="https://capsule-render.vercel.app/api?type=waving&color=0:0f2027,50:203a43,100:2c5364&height=180&section=header&text=Mohammad%20Mahdi%20Zadhosh&fontSize=40&fontColor=39ff88&animation=fadeIn&fontAlignY=38&desc=Full-Stack%20Developer%20%7C%20C%23%20%E2%80%A2%20PHP%20%E2%80%A2%20JS&descAlignY=58&descAlign=50" width="100%"/>

<img src="./assets/matrix-banner.svg" width="100%" alt="matrix banner"/>

<a href="https://github.com/MMZadhosh">
  <img src="https://readme-typing-svg.demolab.com?font=Fira+Code&weight=600&size=22&duration=3000&pause=800&color=39FF88&center=true&vCenter=true&width=600&lines=CS+Undergrad+%26+Full-Stack+Developer;Building+with+C%23+%E2%80%A2+PHP+%E2%80%A2+JavaScript;Always+expanding+my+tech+stack+%F0%9F%9A%80" alt="Typing SVG" />
</a>

<br/>

![Profile Views](https://komarev.com/ghpvc/?username=MMZadhosh&color=39ff88&style=flat-square&label=Profile+Views)
![GitHub followers](https://img.shields.io/github/followers/MMZadhosh?label=Followers&style=flat-square&color=39ff88)

</div>

---

### 🧑‍💻 About Me

- 🎓 Computer Science undergrad, always building side projects
- 🛠️ Working with **C#**, **PHP**, **JavaScript / Node.js**
- ☁️ Comfortable with **Cloudflare Workers**, serverless architecture, and API design
- 📈 Constantly expanding my stack and shipping small useful tools
- 💬 Ask me about backend systems, automation, and Telegram bots

---

### 🧰 Tech Stack

<div align="center">
  <img src="https://skillicons.dev/icons?i=cs,php,js,nodejs,cloudflare,git,github,html,css,mysql,vscode&theme=dark" />
</div>

---

### 📊 GitHub Stats

<div align="center">
  <img height="165" src="https://github-readme-stats.vercel.app/api?username=MMZadhosh&show_icons=true&theme=dark&hide_border=true&bg_color=0a0e0a&title_color=39ff88&icon_color=39ff88&text_color=c9d1d9" />
  <img height="165" src="https://github-readme-streak-stats.herokuapp.com/?user=MMZadhosh&theme=dark&hide_border=true&background=0a0e0a&ring=39ff88&fire=39ff88&currStreakLabel=39ff88" />
</div>

<div align="center">
  <img src="https://github-readme-stats.vercel.app/api/top-langs/?username=MMZadhosh&layout=compact&theme=dark&hide_border=true&bg_color=0a0e0a&title_color=39ff88&text_color=c9d1d9" />
</div>

---

### 🐍 Contribution Snake

<div align="center">
  <img src="https://raw.githubusercontent.com/MMZadhosh/MMZadhosh/output/github-contribution-grid-snake-dark.svg" width="100%"/>
</div>

> این بخش با یک GitHub Action رایگان ساخته میشه، پایین توضیح دادم چطور فعالش کنی.

---

### 🌐 Connect with me

<div align="center">
  <a href="https://t.me/YOUR_TELEGRAM"><img src="https://img.shields.io/badge/Telegram-2CA5E0?style=for-the-badge&logo=telegram&logoColor=white"/></a>
  <a href="mailto:YOUR_EMAIL"><img src="https://img.shields.io/badge/Email-D14836?style=for-the-badge&logo=gmail&logoColor=white"/></a>
</div>

<img src="https://capsule-render.vercel.app/api?type=waving&color=0:2c5364,50:203a43,100:0f2027&height=100&section=footer" width="100%"/>
